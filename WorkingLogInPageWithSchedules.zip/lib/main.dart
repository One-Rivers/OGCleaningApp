import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'pages/login.dart';

void main() => runApp(const MyApp());

// ── Shift Model (mirrors your MongoDB schema) ──────────────────
class Shift {
  final String? id;
  final int employeeId;
  final String locationId;
  final DateTime scheduleStart;
  final DateTime scheduleEnd;
  final bool clockIn;
  final bool clockOut;
  final bool managerApproval;

  Shift({
    this.id,
    required this.employeeId,
    required this.locationId,
    required this.scheduleStart,
    required this.scheduleEnd,
    this.clockIn = false,
    this.clockOut = true,
    this.managerApproval = false,
  });

  factory Shift.fromJson(Map<String, dynamic> json) {
    return Shift(
      id: json['_id'],
      employeeId: json['employeeid'],
      locationId: json['locationid'],
      scheduleStart: DateTime.parse(json['scheduleStart']),
      scheduleEnd: DateTime.parse(json['scheduleEnd']),
      clockIn: json['clockIn'] ?? false,
      clockOut: json['clockOut'] ?? true,
      managerApproval: json['managerApproval'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'employeeid': employeeId,
        'locationid': locationId,
        'scheduleStart': scheduleStart.toIso8601String(),
        'scheduleEnd': scheduleEnd.toIso8601String(),
        'clockIn': clockIn,
        'clockOut': clockOut,
        'managerApproval': managerApproval,
      };
}

// ── App Root — Login is the first screen ──────────────────────
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OG Cleaning Scheduler',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const SignInFive(), // ← Login is first
      routes: {
        '/scheduler': (_) => const ShiftSchedulerPage(),
      },
    );
  }
}

// ── Main Scheduler Page ────────────────────────────────────────
class ShiftSchedulerPage extends StatefulWidget {
  const ShiftSchedulerPage({super.key});

  @override
  State<ShiftSchedulerPage> createState() => _ShiftSchedulerPageState();
}

class _ShiftSchedulerPageState extends State<ShiftSchedulerPage> {
  static const String baseUrl = 'https://ogcleaningapp.onrender.com';

  List<Shift> _shifts = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchShifts();
  }

  Future<void> _fetchShifts() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final response = await http.get(Uri.parse('$baseUrl/getShifts'));
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() {
          _shifts = data.map((j) => Shift.fromJson(j)).toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Server error: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Cannot reach server.';
        _isLoading = false;
      });
    }
  }

  Future<void> _createShift(Shift shift) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/createShifts'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(shift.toJson()),
      );
      if (response.statusCode == 200) _fetchShifts();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to create shift')),
        );
      }
    }
  }

  void _showAddShiftDialog() {
    showDialog(
        context: context,
        builder: (_) => AddShiftDialog(onSubmit: _createShift));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OG Cleaning Scheduler'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _fetchShifts),
        ],
      ),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddShiftDialog,
        icon: const Icon(Icons.add),
        label: const Text('Add Shift'),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.error_outline, size: 48, color: Colors.red),
        const SizedBox(height: 12),
        Text(_error!, style: const TextStyle(color: Colors.red)),
        const SizedBox(height: 16),
        ElevatedButton(onPressed: _fetchShifts, child: const Text('Retry')),
      ]));
    }
    if (_shifts.isEmpty)
      return const Center(child: Text('No shifts yet. Tap + to add one!'));
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _shifts.length,
      itemBuilder: (_, i) => ShiftCard(shift: _shifts[i]),
    );
  }
}

class ShiftCard extends StatelessWidget {
  final Shift shift;
  const ShiftCard({super.key, required this.shift});

  String _fmt(DateTime dt) =>
      '${dt.month}/${dt.day}/${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Employee #${shift.employeeId}',
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            _ApprovalChip(approved: shift.managerApproval),
          ]),
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.location_on, size: 16, color: Colors.grey),
            const SizedBox(width: 4),
            Text(shift.locationId, style: const TextStyle(color: Colors.grey)),
          ]),
          const Divider(height: 20),
          _InfoRow(Icons.login, 'Start', _fmt(shift.scheduleStart)),
          const SizedBox(height: 4),
          _InfoRow(Icons.logout, 'End', _fmt(shift.scheduleEnd)),
          const SizedBox(height: 10),
          Row(children: [
            _StatusBadge('Clocked In', shift.clockIn, Colors.green),
            const SizedBox(width: 12),
            _StatusBadge('Clocked Out', shift.clockOut, Colors.orange),
          ]),
        ]),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow(this.icon, this.label, this.value);
  @override
  Widget build(BuildContext context) => Row(children: [
        Icon(icon, size: 16, color: Colors.blue),
        const SizedBox(width: 6),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
        Text(value),
      ]);
}

class _ApprovalChip extends StatelessWidget {
  final bool approved;
  const _ApprovalChip({required this.approved});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: approved ? Colors.green.shade100 : Colors.orange.shade100,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(approved ? '✓ Approved' : 'Pending',
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color:
                    approved ? Colors.green.shade800 : Colors.orange.shade800)),
      );
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  const _StatusBadge(this.label, this.active, this.color);
  @override
  Widget build(BuildContext context) => Row(children: [
        Icon(active ? Icons.check_circle : Icons.radio_button_unchecked,
            size: 14, color: active ? color : Colors.grey),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 12)),
      ]);
}

class AddShiftDialog extends StatefulWidget {
  final Future<void> Function(Shift) onSubmit;
  const AddShiftDialog({super.key, required this.onSubmit});
  @override
  State<AddShiftDialog> createState() => _AddShiftDialogState();
}

class _AddShiftDialogState extends State<AddShiftDialog> {
  final _formKey = GlobalKey<FormState>();
  final _empIdCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  DateTime? _start, _end;
  bool _submitting = false;

  Future<void> _pickDateTime(bool isStart) async {
    final date = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now().subtract(const Duration(days: 365)),
        lastDate: DateTime.now().add(const Duration(days: 365)));
    if (date == null || !mounted) return;
    final time =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (time == null) return;
    final dt =
        DateTime(date.year, date.month, date.day, time.hour, time.minute);
    setState(() => isStart ? _start = dt : _end = dt);
  }

  String _fmtPicked(DateTime? dt) => dt == null
      ? 'Tap to select'
      : '${dt.month}/${dt.day}/${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_start == null || _end == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Select start and end times')));
      return;
    }
    setState(() => _submitting = true);
    await widget.onSubmit(Shift(
      employeeId: int.parse(_empIdCtrl.text.trim()),
      locationId: _locationCtrl.text.trim(),
      scheduleStart: _start!,
      scheduleEnd: _end!,
    ));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add New Shift'),
      content: SingleChildScrollView(
          child: Form(
              key: _formKey,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextFormField(
                    controller: _empIdCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Employee ID',
                        prefixIcon: Icon(Icons.badge)),
                    keyboardType: TextInputType.number,
                    validator: (v) =>
                        (v == null || v.isEmpty) ? 'Required' : null),
                const SizedBox(height: 12),
                TextFormField(
                    controller: _locationCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Location ID',
                        prefixIcon: Icon(Icons.location_on)),
                    validator: (v) =>
                        (v == null || v.isEmpty) ? 'Required' : null),
                const SizedBox(height: 16),
                ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.login, color: Colors.blue),
                    title: const Text('Schedule Start'),
                    subtitle: Text(_fmtPicked(_start)),
                    onTap: () => _pickDateTime(true)),
                ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.logout, color: Colors.blue),
                    title: const Text('Schedule End'),
                    subtitle: Text(_fmtPicked(_end)),
                    onTap: () => _pickDateTime(false)),
              ]))),
      actions: [
        TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel')),
        ElevatedButton(
            onPressed: _submitting ? null : _submit,
            child: _submitting
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save Shift')),
      ],
    );
  }
}
