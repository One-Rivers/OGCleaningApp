import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class SignInFive extends StatefulWidget {
  const SignInFive({Key? key}) : super(key: key);

  @override
  State<SignInFive> createState() => _SignInFiveState();
}

class _SignInFiveState extends State<SignInFive> {
  static const String baseUrl = 'https://ogcleaningapp.onrender.com';

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  bool _isLoading = false;

  // ── Login Logic ─────────────────────────────────────────────
  Future<void> _login() async {
    final email = emailController.text.trim();
    final password = passController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter email and password')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        // Employee found — go to the scheduler
        Navigator.pushReplacementNamed(context, '/scheduler');
      } else {
        final body = jsonDecode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(body['error'] ?? 'Invalid credentials')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not connect to server')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ── UI ───────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: const Color(0xFF21899C),
      body: SafeArea(
        child: SizedBox(
          height: size.height,
          child: Stack(
            children: <Widget>[
              Positioned(
                left: -34,
                top: 181.0,
                child: SvgPicture.string(
                    '<svg viewBox="-34.0 181.0 99.0 99.0" ><path transform="translate(-34.0, 181.0)" d="M 74.25 0 L 99 49.5 L 74.25 99 L 24.74999618530273 99 L 0 49.49999618530273 L 24.7500057220459 0 Z" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-26.57, 206.25)" d="M 0 0 L 42.07500076293945 16.82999992370605 L 84.15000152587891 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(15.5, 223.07)" d="M 0 56.42999649047852 L 0 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
                    width: 99.0,
                    height: 99.0),
              ),
              Positioned(
                right: -52,
                top: 45.0,
                child: SvgPicture.string(
                    '<svg viewBox="288.0 45.0 139.0 139.0" ><path transform="translate(288.0, 45.0)" d="M 104.25 0 L 139 69.5 L 104.25 139 L 34.74999618530273 139 L 0 69.5 L 34.75000762939453 0 Z" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(298.42, 80.45)" d="M 0 0 L 59.07500076293945 23.63000106811523 L 118.1500015258789 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(357.5, 104.07)" d="M 0 79.22999572753906 L 0 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.25" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
                    width: 139.0,
                    height: 139.0),
              ),
              Positioned(
                top: 8.0,
                child: SizedBox(
                  width: size.width,
                  height: size.height,
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: size.width * 0.06),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                            flex: 3,
                            child: Column(children: [
                              const SizedBox(height: 16),
                              richText(23.12),
                            ])),
                        Expanded(
                            flex: 1,
                            child: Text(
                              'Sign in with your employee account',
                              style: GoogleFonts.inter(
                                  fontSize: 14.0, color: Colors.white),
                            )),
                        Expanded(
                            flex: 4,
                            child: Column(children: [
                              emailTextField(size),
                              const SizedBox(height: 8),
                              passwordTextField(size),
                              const SizedBox(height: 16),
                              buildRemember(size),
                            ])),
                        Expanded(
                            flex: 2,
                            child: Column(children: [
                              signInButton(size),
                              const SizedBox(height: 16),
                              buildContinueText(),
                            ])),
                        Expanded(
                            flex: 4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                signInGoogleFacebookButton(size),
                                const SizedBox(height: 16),
                                buildFooter(size),
                              ],
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget richText(double fontSize) {
    return Text.rich(TextSpan(
      style: GoogleFonts.inter(
          fontSize: 23.12, color: Colors.white, letterSpacing: 2.0),
      children: const [
        TextSpan(text: 'LOGIN', style: TextStyle(fontWeight: FontWeight.w800)),
        TextSpan(
            text: 'PAGE',
            style: TextStyle(
                color: Color(0xFFFE9879), fontWeight: FontWeight.w800)),
      ],
    ));
  }

  Widget emailTextField(Size size) {
    return Container(
      alignment: Alignment.center,
      height: size.height / 12,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: const Color(0xFF4DA1B0)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Row(children: <Widget>[
          const Icon(Icons.mail_rounded, color: Colors.white70),
          const SizedBox(width: 16),
          SvgPicture.string(
              '<svg viewBox="99.0 332.0 1.0 15.5" ><path transform="translate(99.0, 332.0)" d="M 0 0 L 0 15.5" fill="none" fill-opacity="0.6" stroke="#ffffff" stroke-width="1" stroke-opacity="0.6" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
              width: 1.0,
              height: 15.5),
          const SizedBox(width: 16),
          Expanded(
              child: TextField(
            controller: emailController,
            maxLines: 1,
            cursorColor: Colors.white70,
            keyboardType: TextInputType.emailAddress,
            style: GoogleFonts.inter(
                fontSize: 14.0,
                color: Colors.white,
                fontWeight: FontWeight.w500),
            decoration: InputDecoration(
                hintText: 'Enter your email address',
                hintStyle: GoogleFonts.inter(
                    fontSize: 14.0,
                    color: Colors.white70,
                    fontWeight: FontWeight.w500),
                border: InputBorder.none),
          )),
        ]),
      ),
    );
  }

  Widget passwordTextField(Size size) {
    return Container(
      alignment: Alignment.center,
      height: size.height / 12,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: const Color(0xFF4DA1B0)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Row(children: <Widget>[
          const Icon(Icons.lock, color: Colors.white70),
          const SizedBox(width: 16),
          SvgPicture.string(
              '<svg viewBox="99.0 332.0 1.0 15.5" ><path transform="translate(99.0, 332.0)" d="M 0 0 L 0 15.5" fill="none" fill-opacity="0.6" stroke="#ffffff" stroke-width="1" stroke-opacity="0.6" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
              width: 1.0,
              height: 15.5),
          const SizedBox(width: 16),
          Expanded(
              child: TextField(
            controller: passController,
            maxLines: 1,
            cursorColor: Colors.white70,
            obscureText: true,
            style: GoogleFonts.inter(
                fontSize: 14.0,
                color: Colors.white,
                fontWeight: FontWeight.w500),
            decoration: InputDecoration(
                hintText: 'Enter your password',
                hintStyle: GoogleFonts.inter(
                    fontSize: 14.0,
                    color: Colors.white70,
                    fontWeight: FontWeight.w500),
                suffixIcon: const Icon(Icons.visibility, color: Colors.white70),
                border: InputBorder.none),
          )),
        ]),
      ),
    );
  }

  Widget buildRemember(Size size) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
      Container(
        alignment: Alignment.center,
        width: 17.0,
        height: 17.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.0),
          gradient: const LinearGradient(
              begin: Alignment(5.65, -1.0),
              end: Alignment(-1.0, 1.94),
              colors: [Color(0xFF00AD8F), Color(0xFF7BF4DF)]),
        ),
        child: SvgPicture.string(
            '<svg viewBox="47.0 470.0 7.0 4.0" ><path transform="translate(47.0, 470.0)" d="M 0 1.5 L 2.692307710647583 4 L 7 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" /></svg>',
            width: 7.0,
            height: 4.0),
      ),
      const SizedBox(width: 16),
      Text('Remember me',
          style: GoogleFonts.inter(
              fontSize: 14.0,
              color: Colors.white,
              fontWeight: FontWeight.w600)),
    ]);
  }

  // ── Sign In Button — now calls _login() ──────────────────────
  Widget signInButton(Size size) {
    return GestureDetector(
      onTap: _isLoading ? null : _login,
      child: Container(
        alignment: Alignment.center,
        height: size.height / 13,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: _isLoading ? const Color(0xFFc45530) : const Color(0xFFF56B3F),
        ),
        child: _isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2))
            : Text('Sign in',
                style: GoogleFonts.inter(
                    fontSize: 16.0,
                    color: Colors.white,
                    fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget buildContinueText() {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
      const Expanded(child: Divider(color: Colors.white)),
      Expanded(
          child: Text('Or Continue with',
              style: GoogleFonts.inter(fontSize: 12.0, color: Colors.white),
              textAlign: TextAlign.center)),
      const Expanded(child: Divider(color: Colors.white)),
    ]);
  }

  Widget signInGoogleFacebookButton(Size size) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
      Container(
        alignment: Alignment.center,
        width: size.width / 2.8,
        height: size.height / 13,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(width: 1.0, color: Colors.white)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          SvgPicture.string(
              '<svg viewBox="63.54 641.54 22.92 22.92" ><path transform="translate(63.54, 641.54)" d="M 22.6936149597168 9.214142799377441 L 21.77065277099609 9.214142799377441 L 21.77065277099609 9.166590690612793 L 11.45823860168457 9.166590690612793 L 11.45823860168457 13.74988651275635 L 17.93386268615723 13.74988651275635 C 16.98913192749023 16.41793632507324 14.45055770874023 18.33318138122559 11.45823860168457 18.33318138122559 C 7.661551475524902 18.33318138122559 4.583295345306396 15.25492572784424 4.583295345306396 11.45823860168457 C 4.583295345306396 7.661551475524902 7.661551475524902 4.583295345306396 11.45823860168457 4.583295345306396 C 13.21077632904053 4.583295345306396 14.80519008636475 5.244435787200928 16.01918983459473 6.324374675750732 L 19.26015281677246 3.083411931991577 C 17.21371269226074 1.176188230514526 14.47633838653564 0 11.45823860168457 0 C 5.130426406860352 0 0 5.130426406860352 0 11.45823860168457 C 0 17.78605079650879 5.130426406860352 22.91647720336914 11.45823860168457 22.91647720336914 C 17.78605079650879 22.91647720336914 22.91647720336914 17.78605079650879 22.91647720336914 11.45823860168457 C 22.91647720336914 10.68996334075928 22.83741569519043 9.940022468566895 22.6936149597168 9.214142799377441 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
              width: 22.92,
              height: 22.92),
          const SizedBox(width: 16),
          Text('Google',
              style: GoogleFonts.inter(fontSize: 14.0, color: Colors.white)),
        ]),
      ),
      const SizedBox(width: 16),
      Container(
        alignment: Alignment.center,
        width: size.width / 2.8,
        height: size.height / 13,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(width: 1.0, color: Colors.white)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          SvgPicture.string(
              '<svg viewBox="0.3 0.27 22.44 22.44" ><defs><linearGradient id="gradient" x1="0.500031" y1="0.970054" x2="0.500031" y2="0.0"><stop offset="0.0" stop-color="#ffffffff"  /><stop offset="1.0" stop-color="#ffffffff"  /></linearGradient></defs><path transform="translate(0.3, 0.27)" d="M 9.369577407836914 22.32988739013672 C 4.039577960968018 21.3760986328125 0 16.77546882629395 0 11.22104930877686 C 0 5.049472332000732 5.049472808837891 0 11.22105026245117 0 C 17.39262962341309 0 22.44210624694824 5.049472332000732 22.44210624694824 11.22104930877686 C 22.44210624694824 16.77546882629395 18.40252304077148 21.3760986328125 13.07252502441406 22.32988739013672 L 12.45536518096924 21.8249397277832 L 9.986735343933105 21.8249397277832 L 9.369577407836914 22.32988739013672 Z" fill="url(#gradient)" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>',
              width: 22.44,
              height: 22.44),
          const SizedBox(width: 16),
          Text('Facebook',
              style: GoogleFonts.inter(fontSize: 14.0, color: Colors.white)),
        ]),
      ),
    ]);
  }

  Widget buildFooter(Size size) {
    return Align(
      alignment: Alignment.center,
      child: Text.rich(TextSpan(
        style: GoogleFonts.nunito(fontSize: 16.0, color: Colors.white),
        children: [
          TextSpan(
              text: "Don't have account? ",
              style: GoogleFonts.nunito(fontWeight: FontWeight.w600)),
          TextSpan(
              text: 'Sign up',
              style: GoogleFonts.nunito(
                  color: const Color(0xFFF9CA58), fontWeight: FontWeight.w600)),
        ],
      )),
    );
  }
}
